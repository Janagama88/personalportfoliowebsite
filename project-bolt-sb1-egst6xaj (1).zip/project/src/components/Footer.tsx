import React from 'react';
import { Linkedin, Github, Heart, Code, Sparkles } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-full blur-3xl"></div>
      
      <div className="relative py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12 items-center">
            {/* Left - Brand & Copyright */}
            <div className="text-center md:text-left">
              <div className="mb-4">
                <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  Priya Deepika Janagama
                </h3>
                <p className="text-gray-300 text-sm mt-1">Software & Data Innovator</p>
              </div>
              <p className="text-gray-400 text-sm">
                © {currentYear} All rights reserved
              </p>
            </div>

            {/* Center - Mission Statement */}
            <div className="text-center">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
                <p className="text-gray-200 flex items-center justify-center space-x-2 mb-2">
                  <Code className="w-4 h-4 text-blue-400" />
                  <span>Committed to leveraging technology for innovative solutions</span>
                  <Heart className="w-4 h-4 text-red-400" />
                </p>
                <p className="text-sm text-gray-400 flex items-center justify-center space-x-2">
                  <Sparkles className="w-3 h-3 text-purple-400" />
                  <span>Building the future, one line of code at a time</span>
                </p>
              </div>
            </div>

            {/* Right - Social Links */}
            <div className="flex justify-center md:justify-end space-x-4">
              <a
                href="https://linkedin.com/in/priya-deepika-janagama-a9205929b"
                target="_blank"
                rel="noopener noreferrer"
                className="group bg-white/10 backdrop-blur-sm p-4 rounded-2xl hover:bg-blue-600/20 transition-all duration-300 border border-white/10 hover:border-blue-400/30 transform hover:scale-110"
                aria-label="LinkedIn Profile"
              >
                <Linkedin className="w-6 h-6 text-gray-300 group-hover:text-blue-400 transition-colors" />
              </a>
              <a
                href="https://github.com/Janagama88"
                target="_blank"
                rel="noopener noreferrer"
                className="group bg-white/10 backdrop-blur-sm p-4 rounded-2xl hover:bg-gray-600/20 transition-all duration-300 border border-white/10 hover:border-gray-400/30 transform hover:scale-110"
                aria-label="GitHub Profile"
              >
                <Github className="w-6 h-6 text-gray-300 group-hover:text-gray-100 transition-colors" />
              </a>
            </div>
          </div>

          <div className="border-t border-white/10 mt-12 pt-8">
            <div className="text-center">
              <div className="bg-gradient-to-r from-blue-600/10 to-purple-600/10 rounded-2xl p-6 border border-white/10 backdrop-blur-sm">
                <p className="text-gray-300 mb-4 font-medium">
                  Currently seeking internship and full-time opportunities in software development and data analysis
                </p>
                <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-400">
                  <span className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                    <span>Computer Science & Engineering Student</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                    <span>CMR Institute of Technology</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full"></div>
                    <span>Class of 2026</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-red-400 rounded-full"></div>
                    <span>Hyderabad, India</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;