import React, { useEffect, useRef, useState } from 'react';
import { ExternalLink, Github, Users, Trophy, Lightbulb, Shield, ArrowUpRight, Calendar, MapPin } from 'lucide-react';

const Portfolio = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const projects = [
    {
      icon: <ExternalLink className="w-8 h-8 text-blue-600" />,
      title: "Personal Portfolio Website",
      context: "Solo Developer, Personal Initiative",
      duration: "2 weeks",
      status: "Live",
      problem: "To create a central, professional digital identity to effectively showcase my technical skills, project experience, and professional capabilities to potential employers and collaborators.",
      solution: "Engineered a fully responsive, high-performance website from scratch using modern web standards. Focused on a minimalist UI/UX, fast load times (achieving a 95+ Google Lighthouse score), and semantic HTML for accessibility.",
      technologies: ["HTML5", "CSS3", "JavaScript", "Git"],
      category: "Web Development",
      gradient: "from-blue-500 to-cyan-500",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    {
      icon: <Lightbulb className="w-8 h-8 text-green-600" />,
      title: "AI-Powered Social Media Content Generator",
      context: "AI Prompt Engineer, Proof-of-Concept",
      duration: "3 weeks",
      status: "Prototype",
      problem: "Content creation for social media can be time-consuming and repetitive. Businesses need a way to rapidly generate creative and diverse post ideas.",
      solution: "Developed a tool utilizing the ChatGPT API and advanced prompt engineering techniques to generate context-aware, engaging social media copy. The system was designed to accept brand voice parameters for customized output.",
      technologies: ["ChatGPT API", "Prompt Engineering", "Python", "AI/ML"],
      category: "AI & Automation",
      gradient: "from-green-500 to-emerald-500",
      bgColor: "bg-green-50",
      borderColor: "border-green-200"
    },
    {
      icon: <Shield className="w-8 h-8 text-purple-600" />,
      title: "DKIM Implementation for Email Security",
      context: "Team Lead, Academic Research Project",
      duration: "4 weeks",
      status: "Research Complete",
      problem: "Email spoofing and phishing attacks represent a significant cybersecurity threat. Organizations need robust authentication methods to protect their domain reputation and users.",
      solution: "Led a team to research, document, and present a comprehensive implementation strategy for DomainKeys Identified Mail (DKIM). My role included delegating tasks, managing timelines, and synthesizing technical findings into a clear, actionable report.",
      outcome: "Demonstrated a deep understanding of email security protocols and honed skills in team leadership, technical documentation, and project coordination.",
      technologies: ["Cybersecurity Research", "Email Authentication", "Team Leadership"],
      category: "Security & Research",
      gradient: "from-purple-500 to-violet-500",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200"
    },
    {
      icon: <Users className="w-8 h-8 text-indigo-600" />,
      title: "Student Hub Initiative",
      context: "Project Coordinator, University Program",
      duration: "6 weeks",
      status: "Planning Phase",
      problem: "Student resources, club activities, and academic announcements were fragmented across multiple disconnected platforms, leading to poor engagement and information silos.",
      solution: "Coordinated the initial research and planning phase for a unified 'Student Hub' platform. Conducted surveys, facilitated focus groups with students and faculty, and helped define the core feature set for the proposed platform.",
      outcome: "Developed crucial skills in user research, stakeholder management, and requirements gathering, providing a foundational blueprint for the development team.",
      technologies: ["Project Coordination", "User Research", "Requirements Analysis"],
      category: "Project Management",
      gradient: "from-indigo-500 to-blue-500",
      bgColor: "bg-indigo-50",
      borderColor: "border-indigo-200"
    }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Web Development': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'AI & Automation': return 'bg-green-100 text-green-800 border-green-200';
      case 'Security & Research': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Project Management': return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Live': return 'bg-green-100 text-green-800 border-green-200';
      case 'Prototype': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Research Complete': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Planning Phase': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <section ref={sectionRef} id="portfolio" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30 translate-y-48 -translate-x-48"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className={`text-center mb-16 transform transition-all duration-1000 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="inline-flex items-center space-x-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Trophy className="w-4 h-4" />
            <span>Portfolio</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Project 
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Showcase</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            A selection of projects where I have applied my skills to solve specific challenges
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div 
              key={index} 
              className={`group transform transition-all duration-500 delay-${index * 100} ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
              }`}
              onMouseEnter={() => setHoveredProject(index)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              <div className={`bg-white rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden border-2 ${project.borderColor} hover:border-opacity-50 h-full`}>
                {/* Project Header */}
                <div className={`${project.bgColor} p-6 relative overflow-hidden`}>
                  <div className={`absolute inset-0 bg-gradient-to-r ${project.gradient} opacity-10`}></div>
                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div className={`p-3 bg-white rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                          {project.icon}
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {project.title}
                          </h3>
                          <p className="text-sm text-gray-600 mt-1">{project.context}</p>
                        </div>
                      </div>
                      <ArrowUpRight className={`w-5 h-5 text-gray-400 group-hover:text-blue-600 transform transition-all duration-300 ${
                        hoveredProject === index ? 'translate-x-1 -translate-y-1' : ''
                      }`} />
                    </div>
                    
                    <div className="flex items-center space-x-4 text-sm">
                      <div className="flex items-center space-x-1 text-gray-600">
                        <Calendar className="w-4 h-4" />
                        <span>{project.duration}</span>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(project.status)}`}>
                        {project.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Project Content */}
                <div className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                        <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                        Problem
                      </h4>
                      <p className="text-gray-600 text-sm leading-relaxed pl-4 border-l-2 border-red-100">
                        {project.problem}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                        Solution
                      </h4>
                      <p className="text-gray-600 text-sm leading-relaxed pl-4 border-l-2 border-green-100">
                        {project.solution}
                      </p>
                    </div>

                    {project.outcome && (
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                          Key Outcome
                        </h4>
                        <p className="text-gray-600 text-sm leading-relaxed pl-4 border-l-2 border-blue-100">
                          {project.outcome}
                        </p>
                      </div>
                    )}

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-2"></div>
                        Technologies
                      </h4>
                      <div className="flex flex-wrap gap-2 pl-4">
                        {project.technologies.map((tech, techIndex) => (
                          <span
                            key={techIndex}
                            className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg font-medium transition-colors duration-200"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Project Footer */}
                <div className="px-6 pb-6">
                  <div className="flex items-center justify-between">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getCategoryColor(project.category)}`}>
                      {project.category}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className={`text-center mt-16 transform transition-all duration-1000 delay-800 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100 max-w-2xl mx-auto">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Interested in Collaboration?</h3>
            <p className="text-gray-600 mb-6">
              I'm always excited to discuss new projects and opportunities where I can apply my skills to create meaningful impact.
            </p>
            <button
              onClick={() => {
                const element = document.getElementById('contact');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Get In Touch
              <ArrowUpRight className="ml-2 w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;