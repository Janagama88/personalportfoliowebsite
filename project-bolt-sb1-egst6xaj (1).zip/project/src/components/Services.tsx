import React, { useEffect, useRef, useState } from 'react';
import { Globe, BarChart3, Cog, Brain, ArrowRight, CheckCircle, Star } from 'lucide-react';

const Services = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredService, setHoveredService] = useState<number | null>(null);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      icon: <Globe className="w-10 h-10 text-blue-600" />,
      title: "Full-Stack Web Development",
      description: "Architecting and developing high-performance, responsive websites and web applications. From front-end interfaces with HTML, CSS, and JavaScript to foundational back-end logic, I deliver clean, maintainable, and scalable code.",
      features: ["Responsive Design", "Modern Frameworks", "Performance Optimization", "Cross-browser Compatibility"],
      gradient: "from-blue-500 to-cyan-500",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      iconBg: "bg-blue-100"
    },
    {
      icon: <BarChart3 className="w-10 h-10 text-green-600" />,
      title: "Data Analysis & Intelligence",
      description: "Transforming raw data into actionable business intelligence. Using Tableau, R Studio, and WEKA, I specialize in data cleaning, analysis, and creating intuitive dashboards that reveal key trends and drive strategic decisions.",
      features: ["Data Visualization", "Statistical Analysis", "Dashboard Creation", "Trend Identification"],
      gradient: "from-green-500 to-emerald-500",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      iconBg: "bg-green-100"
    },
    {
      icon: <Cog className="w-10 h-10 text-purple-600" />,
      title: "RPA & Process Automation",
      description: "Enhancing operational efficiency by designing and deploying Robotic Process Automation (RPA) solutions with UiPath. I identify and automate repetitive, rule-based tasks to reduce costs, minimize human error, and free up valuable team resources.",
      features: ["Process Analysis", "UiPath Development", "Workflow Optimization", "Cost Reduction"],
      gradient: "from-purple-500 to-violet-500",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200",
      iconBg: "bg-purple-100"
    },
    {
      icon: <Brain className="w-10 h-10 text-orange-600" />,
      title: "AI-Enhanced Content & Tools",
      description: "Strategic content generation and AI tool development using Large Language Models like ChatGPT. I apply advanced prompt engineering to create high-quality content, streamline creative workflows, and build custom AI-powered applications.",
      features: ["Prompt Engineering", "Content Generation", "AI Integration", "Workflow Automation"],
      gradient: "from-orange-500 to-red-500",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
      iconBg: "bg-orange-100"
    }
  ];

  return (
    <section ref={sectionRef} id="services" className="py-20 bg-gradient-to-br from-white to-gray-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full blur-3xl opacity-30 -translate-y-48 -translate-x-48"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className={`text-center mb-16 transform transition-all duration-1000 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="inline-flex items-center space-x-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Star className="w-4 h-4" />
            <span>Services</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Areas of 
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Expertise</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            I offer professional services focused on delivering value through technology. My approach is collaborative, 
            detail-oriented, and centered on achieving your goals.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className={`group transform transition-all duration-500 delay-${index * 100} ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
              }`}
              onMouseEnter={() => setHoveredService(index)}
              onMouseLeave={() => setHoveredService(null)}
            >
              <div className={`bg-white rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden border-2 ${service.borderColor} hover:border-opacity-50 h-full relative`}>
                {/* Gradient overlay on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
                
                {/* Service Header */}
                <div className={`${service.bgColor} p-8 relative`}>
                  <div className="flex items-center mb-6">
                    <div className={`${service.iconBg} p-4 rounded-2xl mr-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                      {service.icon}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                        {service.title}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Service Content */}
                <div className="p-8 relative z-10">
                  <p className="text-gray-600 leading-relaxed mb-8 text-base">
                    {service.description}
                  </p>

                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                      Key Capabilities
                    </h4>
                    <ul className="space-y-3">
                      {service.features.map((feature, featureIndex) => (
                        <li 
                          key={featureIndex} 
                          className={`flex items-center text-gray-600 transform transition-all duration-300 delay-${featureIndex * 50} ${
                            hoveredService === index ? 'translate-x-2' : ''
                          }`}
                        >
                          <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mr-4 flex-shrink-0"></div>
                          <span className="text-sm font-medium">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Hover indicator */}
                <div className={`absolute bottom-4 right-4 transform transition-all duration-300 ${
                  hoveredService === index ? 'translate-x-0 opacity-100' : 'translate-x-4 opacity-0'
                }`}>
                  <div className="bg-blue-600 text-white p-2 rounded-full">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className={`mt-20 transform transition-all duration-1000 delay-800 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-12 text-center text-white relative overflow-hidden">
            {/* Background pattern */}
            <div className="absolute inset-0 bg-white opacity-10 bg-grid-pattern"></div>
            
            <div className="relative z-10">
              <h3 className="text-3xl font-bold mb-4">Ready to Start a Project?</h3>
              <p className="text-blue-100 mb-8 max-w-2xl mx-auto text-lg leading-relaxed">
                Whether you need a complete solution or want to discuss how I can contribute to your existing team, 
                I'm here to help bring your ideas to life.
              </p>
              <button
                onClick={() => {
                  const element = document.getElementById('contact');
                  if (element) element.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center px-8 py-4 bg-white text-blue-600 font-semibold rounded-xl hover:bg-gray-50 transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:scale-105"
              >
                Let's Discuss Your Project
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;