import React, { useEffect, useRef, useState } from 'react';
import { Code, Database, Brain, Zap, Users, Target, Award, BookOpen } from 'lucide-react';

const About = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const skills = [
    {
      category: "Languages & Frameworks",
      items: ["Java", "Python", "C", "HTML5", "CSS3", "JavaScript (ES6+)", "SQL (Foundational)"],
      color: "from-blue-500 to-cyan-500"
    },
    {
      category: "Data & Analytics",
      items: ["Tableau", "R Studio", "WEKA", "Data Processing", "Statistical Analysis"],
      color: "from-green-500 to-emerald-500"
    },
    {
      category: "Development & Automation",
      items: ["Git & GitHub", "UiPath (Certified)", "Arduino", "AI/ML Concepts", "ChatGPT API"],
      color: "from-purple-500 to-violet-500"
    },
    {
      category: "Professional Skills",
      items: ["Agile Methodologies", "Project Leadership", "Stakeholder Communication", "Problem-Solving"],
      color: "from-orange-500 to-red-500"
    }
  ];

  const values = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Clean Code",
      description: "Writing maintainable, efficient code that follows best practices and industry standards.",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "Data-Driven",
      description: "Making informed decisions based on thorough analysis and meaningful insights.",
      color: "text-green-600",
      bgColor: "bg-green-50",
      borderColor: "border-green-200"
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Continuous Learning",
      description: "Staying current with emerging technologies and expanding technical expertise.",
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Innovation",
      description: "Applying creative problem-solving to build impactful technological solutions.",
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200"
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Collaboration",
      description: "Working effectively in teams and communicating complex concepts clearly.",
      color: "text-indigo-600",
      bgColor: "bg-indigo-50",
      borderColor: "border-indigo-200"
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: "Results-Focused",
      description: "Delivering solutions that create real value and drive measurable outcomes.",
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200"
    }
  ];

  return (
    <section ref={sectionRef} id="about" className="py-20 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full blur-3xl opacity-30 -translate-y-48 translate-x-48"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className={`text-center mb-16 transform transition-all duration-1000 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="inline-flex items-center space-x-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <BookOpen className="w-4 h-4" />
            <span>About Me</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            My Mission & 
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Technical Stack</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Driven to contribute to forward-thinking organizations where I can help architect the future of technology
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-20">
          {/* Professional Summary */}
          <div className={`transform transition-all duration-1000 delay-200 ${
            isVisible ? 'translate-x-0 opacity-100' : '-translate-x-10 opacity-0'
          }`}>
            <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100 hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center space-x-3 mb-6">
                <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Professional Summary</h3>
              </div>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p className="relative pl-4 border-l-2 border-blue-200">
                  My academic foundation in Computer Science and Engineering at CMR Institute of Technology (Class of 2026) 
                  has been the launchpad for a deep dive into software engineering and data science. I am passionate about 
                  not just learning theory, but applying it to build robust, impactful solutions.
                </p>
                <p className="relative pl-4 border-l-2 border-purple-200">
                  My approach is rooted in a commitment to clean code, data-driven decisions, and continuous improvement. 
                  I have honed my skills through rigorous academic projects, technical internships, and leadership roles, 
                  developing a versatile skill set that spans development, analysis, and automation.
                </p>
                <p className="relative pl-4 border-l-2 border-green-200">
                  I am driven to contribute to a forward-thinking organization where I can help architect the future of technology.
                </p>
              </div>
            </div>
          </div>

          {/* Core Competencies */}
          <div className={`transform transition-all duration-1000 delay-400 ${
            isVisible ? 'translate-x-0 opacity-100' : 'translate-x-10 opacity-0'
          }`}>
            <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100 hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center space-x-3 mb-6">
                <div className="p-2 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg">
                  <Code className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Core Competencies</h3>
              </div>
              <div className="space-y-6">
                {skills.map((skillGroup, index) => (
                  <div key={index} className="group">
                    <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-4 hover:from-gray-100 hover:to-gray-200 transition-all duration-300">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${skillGroup.color}`}></div>
                        <h4 className="font-semibold text-gray-900">{skillGroup.category}</h4>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {skillGroup.items.map((skill, skillIndex) => (
                          <span
                            key={skillIndex}
                            className="px-3 py-1 bg-white text-gray-700 text-sm rounded-full border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all duration-200"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Values & Approach */}
        <div className={`transform transition-all duration-1000 delay-600 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Values & Approach</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              The principles that guide my work and drive my commitment to excellence
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div 
                key={index} 
                className={`group hover:transform hover:scale-105 transition-all duration-300 delay-${index * 100}`}
              >
                <div className={`${value.bgColor} ${value.borderColor} border-2 rounded-2xl p-6 hover:shadow-xl transition-all duration-300 h-full`}>
                  <div className={`flex justify-center mb-4 ${value.color}`}>
                    {value.icon}
                  </div>
                  <h4 className="font-bold text-gray-900 mb-3 text-center text-lg">{value.title}</h4>
                  <p className="text-gray-600 text-sm leading-relaxed text-center">{value.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;